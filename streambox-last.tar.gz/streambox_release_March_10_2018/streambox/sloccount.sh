#!/bin/sh
sloccount .
#*.h *.cpp micro/*.h micro/*.cpp test/*.h test/*.cpp

# --details
