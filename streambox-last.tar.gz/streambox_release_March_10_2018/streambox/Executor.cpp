#include "core/Executor.h"
long Executor::nwait_ = 0;

