template <class InputT, class OutputT, class DoFnSimpler>
class ParDoSimpler : public PTransform {
public:
  static DoFnSimpler fn;
};
