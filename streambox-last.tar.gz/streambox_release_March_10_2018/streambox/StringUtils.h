/*
 * StringUtils.h
 *
 *  Created on: Jun 19, 2016
 *      Author: xzl
 */

#ifndef STRINGUTILS_H_
#define STRINGUTILS_H_

#include <string>

class StringUtils {
	public static string approximateSimpleName() {
		// todo...
	}
};



#endif /* STRINGUTILS_H_ */
