/*
 * test.cpp
 *
 *  Created on: Jun 18, 2016
 *      Author: xzl
 */

#include <stdio.h>

//#include "Transforms.h"
//#include "values.h"
#include "core/PipelineVisitor.h"
#include "core/Pipeline.h"
#include "Source.h"

int main()
{
	printf("hello world\n");
}
